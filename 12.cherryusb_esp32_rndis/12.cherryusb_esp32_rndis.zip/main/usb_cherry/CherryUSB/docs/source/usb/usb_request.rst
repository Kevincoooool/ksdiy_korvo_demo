USB 设备请求
===========================

本节参考官方 usb2.0 pdf 9.3、9.4 节即可。

.. figure:: img/usb_request.png
